CREATE TABLE IF NOT EXISTS products (
  cj_pid TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  image_url TEXT NOT NULL,
  supplier_price REAL NOT NULL,
  retail_price REAL NOT NULL,
  store_category TEXT NOT NULL,
  cj_sku TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  expires_at INTEGER NOT NULL
);
