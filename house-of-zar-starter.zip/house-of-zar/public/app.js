const $ = (s) => document.querySelector(s);
const state = { products: [], cart: [] };
$('#year').textContent = new Date().getFullYear();
function money(value){ return new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(Number(value)||0); }
function renderProducts(){
  const q = ($('#product-search').value||'').toLowerCase();
  const cat = $('#category-filter').value;
  const list = state.products.filter(p => (!q || (p.name||'').toLowerCase().includes(q)) && (!cat || p.store_category===cat));
  const grid = $('#product-grid');
  if(!list.length){ grid.innerHTML = `<div class="empty-state"><div class="empty-icon">HZ</div><h3>${state.products.length?'No matching products.':'Your collection is being prepared.'}</h3><p>${state.products.length?'Try another search or category.':'Products will appear here only after they are imported from the real CJdropshipping catalogue by the store owner.'}</p><span class="source-label">SUPPLIER: CJDROPSHIPPING</span></div>`; return; }
  grid.innerHTML = list.map(p=>`<article class="product-card"><img src="${escapeAttr(p.image_url)}" alt="${escapeAttr(p.name)}" loading="lazy"><div class="product-info"><h3>${escapeHtml(p.name)}</h3><p>Supplier: CJdropshipping</p><span class="product-price">${money(p.retail_price)}</span><button data-add="${escapeAttr(p.cj_pid)}">Add to bag</button></div></article>`).join('');
}
function escapeHtml(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function escapeAttr(s=''){return escapeHtml(s);}
async function loadProducts(){try{const r=await fetch('/api/products');if(!r.ok)throw new Error('catalogue unavailable');const j=await r.json();state.products=j.products||[];renderProducts();}catch(e){$('#catalog-status').textContent='The live product catalogue is temporarily unavailable. No sample products are being shown.';}}
function renderCart(){ $('#cart-count').textContent=state.cart.reduce((n,x)=>n+x.qty,0); $('#cart-subtotal').textContent=money(state.cart.reduce((n,x)=>n+x.price*x.qty,0)); $('#cart-items').innerHTML=state.cart.length?state.cart.map(x=>`<div class="cart-row"><span>${escapeHtml(x.name)} × ${x.qty}</span><strong>${money(x.price*x.qty)}</strong></div>`).join(''):'<p>Your bag is empty.</p>'; }
$('#product-grid').addEventListener('click',e=>{const b=e.target.closest('[data-add]');if(!b)return;const p=state.products.find(x=>x.cj_pid===b.dataset.add);if(!p)return;const item=state.cart.find(x=>x.pid===p.cj_pid);if(item)item.qty++;else state.cart.push({pid:p.cj_pid,name:p.name,price:Number(p.retail_price),qty:1});renderCart();});
$('#cart-toggle').onclick=()=>$('#cart-drawer').classList.add('open');$('#cart-close').onclick=()=>$('#cart-drawer').classList.remove('open');$('#cart-drawer').addEventListener('click',e=>{if(e.target.id==='cart-drawer')$('#cart-drawer').classList.remove('open');});
$('#checkout-button').onclick=()=>alert('Checkout is not enabled yet. A payment provider and verified CJ fulfilment workflow must be configured before taking customer payments.');
$('#product-search').addEventListener('input',renderProducts);$('#category-filter').addEventListener('change',renderProducts);
document.querySelectorAll('[data-category]').forEach(b=>b.addEventListener('click',()=>{const map={'Cutlery':'Cutlery','Cookware':'Cookware','Dinnerware':'Dinnerware','Appliances':'Appliances','Small appliances':'Small appliances','Accessories':'Accessories'};$('#category-filter').value=map[b.dataset.category]||'';$('#shop').scrollIntoView({behavior:'smooth'});renderProducts();}));
loadProducts();renderCart();
