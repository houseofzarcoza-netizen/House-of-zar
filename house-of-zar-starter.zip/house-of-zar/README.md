# House of Zar — starter store

A mobile-first House of Zar storefront with a Cloudflare Pages Functions backend designed to search and import real CJdropshipping products. No sample products are seeded or displayed.

## Important status

This is a deployable starter, not a finished live store. The included CJ API integration supports server-side authentication, catalogue search, and saving selected supplier products to D1. It does **not** yet implement product detail/variant inventory verification, freight quote calculation, payment processing, customer accounts, order creation/payment to CJ, refunds, or tracking webhooks. Checkout is deliberately disabled so customers cannot pay for unfulfillable orders.

## Stack and cost

- Cloudflare Pages static assets + Pages Functions (Workers Free currently lists 100,000 requests/day; limits can change).
- Cloudflare D1 database (free quota applies; check current Cloudflare pricing/limits).
- A custom domain is optional; the `pages.dev` address can be used initially.
- Payment processing and CJ supplier purchases are not free; payment processors charge fees and supplier products/shipping must be paid for.

## Deploy from a phone

1. Create a GitHub account and a new repository named `house-of-zar`.
2. Upload the contents of this folder to the repository (not the folder wrapper).
3. In Cloudflare Dashboard, open Workers & Pages → Create → Pages → Connect to Git and select the repository.
4. Framework preset: None. Build command: leave blank. Build output directory: `public`.
5. Create a D1 database named `house-of-zar-db` in Cloudflare Dashboard → Workers & Pages → D1. Copy its database ID into `wrangler.toml`.
6. Run the SQL in `schema.sql` in the D1 Console.
7. In the Pages project Settings → Functions → D1 database bindings, add binding name `DB` and select `house-of-zar-db`.
8. In Pages project Settings → Variables and Secrets, add secrets `CJ_API_KEY` and `ADMIN_SECRET`. `CJ_API_KEY` is the key from your CJ account. `ADMIN_SECRET` should be a long random password you create. Never put either value in GitHub or frontend code.
9. Redeploy the project.

## Admin catalogue import

A small admin interface is not included in this first starter; use the API endpoints with an API client for now:

- `GET /api/health` — basic health check.
- `GET /api/products` — public imported catalogue.
- `GET /api/cj-search?q=blender` with header `x-admin-secret: YOUR_ADMIN_SECRET` — searches CJ's real catalogue.
- `POST /api/cj-import` with header `x-admin-secret: YOUR_ADMIN_SECRET` and JSON body `{ "id":"CJ_PRODUCT_ID", "name":"...", "image":"https://...", "sku":"...", "supplierPrice":12.34, "category":"Kitchen appliance", "markupPercent":45 }` — imports a result returned by CJ search. The server computes a retail price in USD.

Only import products returned by the authenticated CJ search endpoint. Do not accept products from other suppliers.

## CJ API notes

Uses CJ API 2.0 token endpoint and `/product/listV2`. Product search fields and response shape follow CJ's current API docs. Before publishing products for sale, implement and test product detail, variants, destination-specific inventory, and freight calculation.

## Before accepting payments

Add and test a payment provider (for example Stripe where available to your business), verify successful and failed payment webhooks, then implement CJ order creation and supplier payment/confirmation. Add customer order tracking and refund handling. Keep checkout disabled until the full paid-order-to-CJ-fulfilment workflow is tested end to end.

## Visual supplier admin

After deployment, open `/admin.html` on your store, enter the `ADMIN_SECRET`, search for kitchen products (for example `cutlery`, `cookware`, `blender`, `kettle`), and press **Import this CJ product**. The admin page sends the secret only as a request header; it does not save it in local storage. Keep `/admin.html` private and do not share your admin secret.
