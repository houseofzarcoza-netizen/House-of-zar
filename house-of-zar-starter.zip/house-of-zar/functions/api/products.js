export async function onRequestGet({env}){
  if(!env.DB) return Response.json({products:[],warning:'Database is not configured yet.'});
  const {results=[]}=await env.DB.prepare('SELECT cj_pid, name, image_url, supplier_price, retail_price, store_category, cj_sku FROM products WHERE active=1 ORDER BY created_at DESC').all();
  return Response.json({products:results});
}
